package com.javarush.task.pro.task06.task0615;

/* 
Все что нужно знать о Земле
*/

public class Earth {
    public static final String NAME = "Земля";
    public static final double SQUARE = 510_100_000;
    public static final long POPULATION = 7_594_000_000L;
    public static final long EQUATOR_LENGTH = 40_075_696;
}
