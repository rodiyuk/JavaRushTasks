package com.javarush.task.pro.task05.task0501;

/* 
Создаем массивы
*/
public class Solution {
    public static int[] initializeIntArray(int l){
        return new int[l];
    }
    public static double[] initializeDoubleArray(int l){
        return new double[l];
    }
    //напишите тут ваш код

}
