package com.javarush.task.pro.task06.task0608;

/* 
Кубический калькулятор
*/

public class Solution {
    public static void main(String[] args) {

    }

    public static long cube(long l){
        return l*l*l;
    }
    //напишите тут ваш код
}
