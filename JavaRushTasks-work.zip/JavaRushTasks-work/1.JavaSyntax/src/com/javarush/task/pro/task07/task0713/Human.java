package com.javarush.task.pro.task07.task0713;

public class Human extends Terran {
}
