package com.javarush.task.pro.task07.task0704;

/* 
Экспонентная запись числа
*/

public class Solution {
    double earthDiameter = 1.2742E+4;
    double lightSpeed = 2.99792458E+8;
    double uraniumAtomicMass = 2.380289E+2;
    double averageBeeWeight = 8.5E-2;
    double javaDeveloperSalary = 1.0E+4;
}
