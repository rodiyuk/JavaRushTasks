package com.javarush.task.pro.task06.task0602;

/* 
Упорядоченная информация
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println("Я — поэт, зовусь я Цветик.");
        System.out.println("От меня вам всем приветик.");
    }
}
