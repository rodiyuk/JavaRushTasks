package com.javarush.task.pro.task08.task0811;

public class Solution {

    public static void main(String[] args) {
        int x = 7;
        x = x & 29;
        x = x & 5;
        //x = x & 3;
        //x = x & 12;
        x = x | 1;
        System.out.println(x);
    }
}
