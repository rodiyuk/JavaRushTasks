package com.javarush.task.pro.task06.task0606;

/* 
Универсальный солдат
*/

public class Solution {

    public static void main(String[] args) {

    }

    public static void universalMethod(){

    }
    public static void universalMethod(int i){

    }
    public static void universalMethod(int a, int b){

    }
    public static void universalMethod(String s){

    }
    public static void universalMethod(String s, int a){

    }
    public static void universalMethod(String s, String a){

    }
    public static void universalMethod(int s, String a){

    }
    public static void universalMethod(String s, int a, int b){

    }
    public static void universalMethod(String s, int a, boolean b){

    }
    public static void universalMethod(String s, int a, double b){

    }

    //напишите тут ваш код
}
