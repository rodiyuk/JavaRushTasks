package com.javarush.task.pro.task07.task0702;

/* 
Максимальное целое
*/

public class Solution {
    //напишите тут ваш код
    byte aByte = Byte.MAX_VALUE;
    short aShort = Short.MAX_VALUE;
    int anInt = Integer.MAX_VALUE;
    long aLong = Long.MAX_VALUE;
}
