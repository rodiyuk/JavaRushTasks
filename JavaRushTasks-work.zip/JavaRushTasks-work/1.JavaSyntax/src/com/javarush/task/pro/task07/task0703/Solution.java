package com.javarush.task.pro.task07.task0703;

/* 
Минимальное целое
*/

public class Solution {
    //напишите тут ваш код
    byte aByte = Byte.MIN_VALUE;
    short aShort = Short.MIN_VALUE;
    int anInt = Integer.MIN_VALUE;
    long aLong = Long.MIN_VALUE;
}
