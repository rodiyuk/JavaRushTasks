package com.javarush.task.pro.task05.task0512;

/* 
Создаем мультимассив
*/

public class Solution {

    public static int[][][] getMultiArray() {
        //напишите тут ваш код
        int [][][] arr = new int[5][10][20];
        return arr;
    }
}
