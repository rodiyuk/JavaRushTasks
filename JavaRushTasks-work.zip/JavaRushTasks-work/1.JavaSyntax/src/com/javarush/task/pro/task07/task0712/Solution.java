package com.javarush.task.pro.task07.task0712;

/* 
Первые объекты
*/

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        String s = new String();
        String s1 = new String();
        String s2 = new String();
        String s3 = new String();
        String s4 = new String();
        String s5 = new String();
        String s6 = new String();
        String s7 = new String();
        String s8 = new String();
        String s9 = new String();
        int[] ints = new int[5];
        int[] ints1 = new int[5];
        int[] ints2 = new int[5];
        int[] ints3 = new int[5];
        int[] ints4 = new int[5];
        Scanner scanner = new Scanner(System.in);
        Scanner scanner1 = new Scanner(System.in);
    }
}
