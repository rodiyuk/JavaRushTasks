package com.javarush.task.pro.task07.task0715;

public class Human extends Entity {
    public void speak(){
        System.out.println("Я умею общаться.");
    }
}
