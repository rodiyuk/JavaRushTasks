package com.javarush.task.pro.task07.task0715;

public class JavaDeveloper extends Human {
    public void code(){
        System.out.println("Я умею общаться на Java.");
    }
}
